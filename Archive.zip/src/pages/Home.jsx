import React from "react";
import Profile from "../images/profile.jpeg";
import HTML from "../images/Html.png";
import CSS from "../images/css.png";
import "./home.css";

export default function Home() {
  return (
    <div className="body-wrapper">
      <div className="section-1">
        <div className="title">
          <h3>
            Hi. I am Niharika Gupta. <br></br>I am a web developer with art and
            designing background. With a good grasp of user experience and
            interactivity, I enjoy designing the user interface for web
            applications. <br></br>
            My keen interest lies in translating user requirements into a
            working product.
            <br></br>
            As a frontend developer, I enjoy solving problems, fixing and
            writing code and learning new things everyday.
          </h3>
        </div>
        <div className="image-wrap">
          <img
            width="150px"
            height="150px"
            src={Profile}
            alt="logo"
            display="flex"
          />
        </div>
      </div>
      <div className="section-2-tech">
        <h3> My Tech Stack </h3>
        <h5> Technologies I have been working with recently are : </h5>
        <div className="header-link">
          <ul className="links">
            <li>
              <img width="100px" height="100px" src={HTML} alt="logo" />
            </li>
            <li>
              <img width="100px" height="100px" src={CSS} alt="logo" />
            </li>
            <li></li>
            <li></li>
          </ul>
        </div>
      </div>
      <div classname="section-3-cards">
        <h3> Projects </h3>
        <h5> Few applications that I have built to showcase my knowledge </h5>
      </div>
    </div>
  );
}
