import React from "react";
import Logonew from "../images/blacklogo.png";
import GitHubIcon from "@mui/icons-material/GitHub";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import IconButton from "@mui/material/IconButton";
import Stack from "@mui/material/Stack";
import "./footer.css";

export default function Footer() {
  return (
    <div className="footer-wrapper">
      <div className="footer-header">
        <div className="footer-image">
          <img
            width="200px"
            height="200px"
            src={Logonew}
            alt="logo"
            display="flex"
          />
        </div>
        <div className="section-wrapper">
          <div className="section-1" style={{ color: "white" }}>
            <h5>+46 70428 5348</h5>
            <h5>niharika0108@gmail.com</h5>
          </div>
        </div>
      </div>
      <hr></hr>
      <div className="footer-content">
        <div className="footer-link">
          <ul className="links">
            <li>
              <a href="">About me</a>
            </li>
            <li>
              <a href="">Tech Stack</a>
            </li>
            <li>
              <a href="">Projects</a>
            </li>
            <li>
              <a href="">Contact</a>
            </li>
          </ul>
          <h5>Designed by Niharika Gupta</h5>
        </div>
        <div>
          <Stack spacing={2} direction="row">
            <IconButton
            //onClick={handleClick}
            >
              <GitHubIcon fontSize="large" sx={{ color: "white" }}></GitHubIcon>
            </IconButton>
            <IconButton
            //onClick={handleClick}
            >
              <LinkedInIcon
                fontSize="large"
                sx={{ color: "white" }}
              ></LinkedInIcon>
            </IconButton>
          </Stack>
        </div>
      </div>
    </div>
  );
}
